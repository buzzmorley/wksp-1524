if(window.localStorage) {                                // Check for local storage

  var txtUserName = document.getElementById('username'); // Get form elements
  var txtAnswer = document.getElementById('answer');
  
  txtUserName.value = localStorage.getItem('username'); // Elements populated by localStorage data
  txtAnswer.value = localStorage.getItem('answer');
  
  txtUserName.addEventListener('input', function() {    // Data saved
    localStorage.setItem('username', txtUserName.value);
    }, false);
    
    txtAnswer.addEventListener('input', function() {    // Data saved
      localStorage.setItem('answer', txtAnswer.value); 
    }, false);
    
}