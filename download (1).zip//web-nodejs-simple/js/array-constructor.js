var colors = new Array('white','black','custom');

var el=document.getElementById('colors');
el.textContent=colors[1];

