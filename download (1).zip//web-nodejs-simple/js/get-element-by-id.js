
// Select the element and store it in a variable
var el = document.getElementById('one');

// Change the value of the class attribute
el.className = 'cool';
