var xhr = new XMLHttpRequest();                 // Create XMLHttpRequest object

xhr.onload = function()  {
    
}