 
 var firstItem = document.getElementById('two');    // Get the first item
 if (firstItem.hasAttribute('class')) {     // If it has a class attribute
 firstItem.removeAttribute('class');
 }