var greeting='Howdy ';
var name = 'Molly';

var welcomeMessage=greeting+name+'!';

var el=document.getElementById('greeting');
el.textContent=welcomeMessage;
