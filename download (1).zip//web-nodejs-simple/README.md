# JAVASCRIPT & JQUERY by Jon Duckett

This repo just contains exersise files form the Wiley book and various other ad hoc experiments.

