'use strict';

/**
 * @ngdoc function
 * @name app1App.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the app1App
 */
angular.module('app1App')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
